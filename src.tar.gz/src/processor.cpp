#include <vector>

#include "processor.h"
#include "linux_parser.h"

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() {
  // code found on Knowledge, by Satya P.: https://knowledge.udacity.com/questions/303127
  std::vector<long> utilvector = LinuxParser::CpuUtilization();
  float cpu_util = 0.0;
  if (prevtotal!=0){
    long total = utilvector[0];
    long idle = utilvector[2];
    long totaldiff = total - prevtotal;
    long idlediff = idle - previdle;
    cpu_util = (1.0 * (totaldiff - idlediff)/totaldiff);
  }
  prevtotal = utilvector[0];
  previdle = utilvector[2];
  return cpu_util;
}