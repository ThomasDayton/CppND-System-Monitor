#include <string>

#include "format.h"

using std::string;

//Code found on Knowledge: https://knowledge.udacity.com/questions/296498
string formatSMH(int val){
    string strval{""};
    if (val < 10){
        strval = "0" + std::to_string(val);
    }
    else{
        strval = std::to_string(val);
    }
    return strval;
}

// TODO: Complete this helper function
// INPUT: Long int measuring seconds
// OUTPUT: HH:MM:SS
// REMOVE: [[maybe_unused]] once you define the function
string Format::ElapsedTime(long seconds) {
  long minutes = seconds / 60;
  long hours = minutes / 60;
  string time = formatSMH(hours) + ":" + formatSMH(minutes%60) + ":" + formatSMH(seconds%60);
  return time;
}